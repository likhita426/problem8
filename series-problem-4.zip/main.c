/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//series-1,1,2,3,4,9,8,27,16,81......n=16//
#include <stdio.h>
#include<math.h>
int main()
{
    int n;
    printf("Enter the value of n:");
    scanf("%d",&n);
    if(n%2==1){
        int term= pow(2,n/2);
        printf("The %dth term ids: %d\n",n,term);
    }
    else
    {
        int term=pow(3,(n/2)-1);
        printf("The %dth term ids: %d\n",n,term);
    }
}